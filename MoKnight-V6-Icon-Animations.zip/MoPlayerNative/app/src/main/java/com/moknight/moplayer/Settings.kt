package com.moknight.moplayer

import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class FontOpt(val key: String, val label: String, val res: Int)

val FONTS = listOf(
    FontOpt("readex", "Readex Pro", R.font.readex_pro),
    FontOpt("cairo", "Cairo", R.font.cairo),
    FontOpt("tajawal", "Tajawal", R.font.tajawal_regular),
    FontOpt("almarai", "Almarai", R.font.almarai_regular),
    FontOpt("kufi", "Noto Kufi", R.font.notokufi),
    FontOpt("messiri", "El Messiri", R.font.elmessiri),
)

private val families: Map<String, FontFamily> by lazy { FONTS.associate { it.key to FontFamily(Font(it.res)) } }
fun familyOf(key: String): FontFamily = families[key] ?: families.getValue("readex")

object AppFont {
    var key by mutableStateOf("readex")
}

object Lang {
    var en by mutableStateOf(false)
}

/** نص عربي/إنجليزي حسب اللغة المختارة. */
fun tr(ar: String, en: String): String = if (Lang.en) en else ar

private val Orange = Color(0xFFFF9800)
private val Red = Color(0xFFFF3B30)

private fun boostColor(v: Float): Color {
    val x = ((v - 100f) / 200f).coerceIn(0f, 1f)
    return if (x < 0.5f) lerp(Sky, Orange, x * 2f) else lerp(Orange, Red, (x - 0.5f) * 2f)
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Navy2.copy(alpha = 0.55f))
            .padding(16.dp)
    ) {
        Text(title, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun Chip(label: String, on: Boolean, family: FontFamily = Readex, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (on) Blue else Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) Color.White else Mut, fontFamily = family, fontSize = 14.sp)
    }
}

@Composable
fun SettingsHost(vm: MainVM, onClose: () -> Unit) {
    val boost by vm.boost.collectAsState()
    val speed by vm.speed.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    var sleepSel by remember { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy2, Navy, Bg0)))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("رجوع", "Back"), tint = Tx)
            }
            Text(tr("الإعدادات", "Settings"), color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Section(tr("رفع الصوت", "Volume boost")) {
                var drag by remember(boost) { mutableFloatStateOf(boost.toFloat()) }
                val col = boostColor(drag)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        tr("مستوى الصوت", "Level"), color = Mut, fontFamily = Readex,
                        fontSize = 13.sp, modifier = Modifier.weight(1f)
                    )
                    Text("${drag.toInt()}%", color = col, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Slider(
                        value = drag,
                        onValueChange = { drag = it },
                        onValueChangeFinished = { vm.setBoost(drag.toInt()) },
                        valueRange = 100f..300f,
                        colors = SliderDefaults.colors(
                            thumbColor = col, activeTrackColor = col,
                            inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                        ),
                    )
                }
                Text(
                    tr("فوق 200% الصوت ممكن يتشوّه في بعض الأغاني.", "Above 200% some tracks may distort."),
                    color = Mut, fontFamily = Readex, fontSize = 12.sp
                )
            }

            Section(tr("سرعة التشغيل", "Playback speed")) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { r ->
                        val label = if (r % 1f == 0f) "${r.toInt()}x" else "${r}x"
                        Chip(label, speed == r) { vm.setSpeed(r) }
                    }
                }
            }

            Section(tr("مؤقت النوم", "Sleep timer")) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                        val on = if (m == 0) sleepLeft <= 0 else (sleepLeft > 0 && sleepSel == m)
                        val label = if (m == 0) tr("إيقاف", "Off") else tr("$m د", "$m min")
                        Chip(label, on) { sleepSel = m; vm.setSleep(m) }
                    }
                }
                if (sleepLeft > 0) Text(
                    tr("هيوقف بعد ${formatTime(sleepLeft)}", "Stops in ${formatTime(sleepLeft)}"),
                    color = Sky, fontFamily = Readex, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            Section(tr("تشغيل مستقر في الخلفية", "Stable background playback")) {
                val ctx = LocalContext.current
                Text(
                    tr(
                        "لو التشغيل بيقف لوحده والشاشة مقفولة، اسمح للتطبيق يشتغل من غير توفير بطارية.",
                        "If playback stops by itself with the screen off, let the app run without battery optimization."
                    ),
                    color = Mut, fontFamily = Readex, fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip(tr("إعدادات البطارية", "Battery settings"), false) {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    }
                    Chip(tr("إعدادات الإشعارات", "Notification settings"), false) {
                        runCatching {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                            )
                        }
                    }
                }
            }

            Section(tr("الخط", "Font")) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FONTS.forEach { f ->
                        Chip(f.label, AppFont.key == f.key, familyOf(f.key)) { vm.setFont(f.key) }
                    }
                }
            }

            Section(tr("اللغة", "Language")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("العربية", !Lang.en) { vm.setLang(false) }
                    Chip("English", Lang.en) { vm.setLang(true) }
                }
            }

            Text(
                "MoPlayer native 7", color = Mut, fontFamily = Readex, fontSize = 12.sp,
                modifier = Modifier.padding(vertical = 18.dp).align(Alignment.CenterHorizontally)
            )
        }
    }
}
