package com.moknight.moplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: Long, val name: String, val ids: List<Long>)
data class Meta(val title: String, val artist: String)

/** تخزين محلي بسيط: القوائم، تعديلات الأسماء، والأغاني المخفية. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("moplayer", Context.MODE_PRIVATE)

    var boost: Int
        get() = sp.getInt("boost", 100)
        set(v) { sp.edit().putInt("boost", v).apply() }
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var font: String
        get() = sp.getString("font", "readex") ?: "readex"
        set(v) { sp.edit().putString("font", v).apply() }
    var lang: String
        get() = sp.getString("lang", "ar") ?: "ar"
        set(v) { sp.edit().putString("lang", v).apply() }

    /** التصنيف المختار في المكتبة (NASHEED / QURAN / OTHER). */
    var cat: String
        get() = sp.getString("cat", "NASHEED") ?: "NASHEED"
        set(v) { sp.edit().putString("cat", v).apply() }
    /** آخر حاجة اتشغلت وموضعها. */
    var lastId: Long
        get() = sp.getLong("lastId", -1L)
        set(v) { sp.edit().putLong("lastId", v).apply() }
    var lastPos: Long
        get() = sp.getLong("lastPos", 0L)
        set(v) { sp.edit().putLong("lastPos", v).apply() }

    var playlists: List<Playlist> = emptyList()
    /** تصنيفات اتغيرت يدوي: id ← اسم التصنيف. */
    var kinds: Map<Long, String> = emptyMap()
    var overrides: Map<Long, Meta> = emptyMap()
    var hidden: Set<Long> = emptySet()

    init {
        runCatching {
            val o = JSONObject(sp.getString("data", "{}") ?: "{}")
            playlists = o.optJSONArray("playlists")?.let { a ->
                (0 until a.length()).map { i ->
                    val p = a.getJSONObject(i)
                    val ids = p.getJSONArray("ids")
                    Playlist(p.getLong("id"), p.getString("name"), (0 until ids.length()).map { ids.getLong(it) })
                }
            } ?: emptyList()
            overrides = o.optJSONObject("over")?.let { ov ->
                ov.keys().asSequence().associate { k ->
                    val m = ov.getJSONObject(k)
                    k.toLong() to Meta(m.getString("t"), m.getString("a"))
                }
            } ?: emptyMap()
            kinds = o.optJSONObject("kinds")?.let { ko ->
                ko.keys().asSequence().associate { k -> k.toLong() to ko.getString(k) }
            } ?: emptyMap()
            hidden = o.optJSONArray("hidden")?.let { a ->
                (0 until a.length()).map { a.getLong(it) }.toSet()
            } ?: emptySet()
        }
    }

    fun save() {
        val o = JSONObject()
        val pa = JSONArray()
        playlists.forEach { p ->
            pa.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids)))
        }
        o.put("playlists", pa)
        val ov = JSONObject()
        overrides.forEach { (id, m) -> ov.put(id.toString(), JSONObject().put("t", m.title).put("a", m.artist)) }
        o.put("over", ov)
        val ko = JSONObject()
        kinds.forEach { (id, k) -> ko.put(id.toString(), k) }
        o.put("kinds", ko)
        o.put("hidden", JSONArray(hidden.toList()))
        sp.edit().putString("data", o.toString()).apply()
    }
}
