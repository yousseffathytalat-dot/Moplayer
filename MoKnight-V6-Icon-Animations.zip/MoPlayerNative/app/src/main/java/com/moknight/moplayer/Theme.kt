package com.moknight.moplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ألوان الواجهة الجديدة (مأخوذة من التصميم)
val Bg0 = Color(0xFF010B26)
val BgMid = Color(0xFF001D51)
val BgLow = Color(0xFF00155A)
val Navy = Color(0xFF041A4D)
val Navy2 = Color(0xFF0A2260)
val Blue = Color(0xFF2F6BFF)
val Violet = Color(0xFF5B3DFF)
val Purple = Color(0xFF6A3DFF)
val Sky = Color(0xFF4CB8FF)
val Tx = Color(0xFFEAF1FF)
val Mut = Color(0xFF8FA3CF)
val CardFill = Color(0xFF051A4C)
val CardLine = Color(0xFF1B3275)
val FieldFill = Color(0xFF071D4C)
val LogoA = Color(0xFF3A5BFF)
val LogoB = Color(0xFF2A0BC8)
val Readex: FontFamily get() = familyOf(AppFont.key)

/** خلفية التطبيق كله. */
val AppBg: Brush get() = Brush.verticalGradient(listOf(Bg0, BgMid, BgLow))

/** لوجو M. */
@Composable
fun MLogo(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Brush.linearGradient(listOf(LogoA, LogoB))),
        contentAlignment = Alignment.Center
    ) {
        Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp)
    }
}


/** تحميل أغلفة الأغاني مع كاش في الذاكرة. */
object ArtLoader {
    private val cache = LruCache<String, Bitmap>(60)
    private val missing = HashSet<String>()

    fun load(ctx: Context, t: Track, px: Int): Bitmap? {
        val key = "${t.id}_$px"
        cache.get(key)?.let { return it }
        if (key in missing) return null
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(t.uri, Size(px, px), null)
            } else {
                ctx.contentResolver.openInputStream(t.artUri)?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        return bmp
    }
}

@Composable
fun Art(t: Track, size: Dp, px: Int, shape: Shape, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, t.id, px) {
        value = withContext(Dispatchers.IO) { ArtLoader.load(ctx, t, px) }
    }
    Box(
        modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(listOf(LogoA, LogoB))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            // الغلاف الافتراضي: نفس المربع المتدرج مع حرف M في المنتصف، فقط لو مفيش صورة حقيقية.
            Text(
                "M",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.5f).sp
            )
        }
    }
}
