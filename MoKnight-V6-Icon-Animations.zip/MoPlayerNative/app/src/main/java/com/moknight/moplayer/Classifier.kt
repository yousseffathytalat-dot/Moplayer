package com.moknight.moplayer

/** تصنيف الملف: أنشودة / قرآن / أخرى. */
enum class Kind { NASHEED, QURAN, OTHER }

fun kindLabel(k: Kind): String = when (k) {
    Kind.NASHEED -> tr("أناشيد", "Nasheeds")
    Kind.QURAN -> tr("القرآن الكريم", "Quran")
    Kind.OTHER -> tr("أخرى", "Other")
}

fun kindOf(name: String?): Kind? = Kind.values().firstOrNull { it.name == name }

/**
 * بيحلل بيانات الملف (الاسم، اسم الملف، الفنان، الألبوم، النوع، المجلد) ويحدد هو قرآن ولا أنشودة.
 * أي حاجة مش قرآن ولا أنشودة (أغاني، بودكاست، إلخ) بتروح على "أخرى".
 * التصنيف بيتحسب بنظام نقط، ولو غلط في ملف معين تقدر تنقله يدوي من أيقونة الترس.
 */
object Classifier {

    /** توحيد الحروف: شيل التشكيل والتطويل، وحّد الألف والياء والتاء المربوطة، وخلّي كل كلمة بين مسافتين. */
    private fun norm(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append(' ')
        var lastSpace = true
        for (ch in s.lowercase()) {
            val c = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                else -> ch
            }
            val code = c.code
            if (code in 0x064B..0x065F || code == 0x0670 || code == 0x0640) continue
            if (c.isLetterOrDigit()) {
                sb.append(c)
                lastSpace = false
            } else if (!lastSpace) {
                sb.append(' ')
                lastSpace = true
            }
        }
        if (!lastSpace) sb.append(' ')
        return sb.toString()
    }

    private fun keys(vararg k: String): List<String> = k.map { norm(it).trim() }

    private fun hasAny(s: String, list: List<String>): Boolean = list.any { s.contains(" $it ") }

    // كلمات صريحة للقرآن
    private val Q_KEYS = keys(
        "سورة", "سوره", "قرآن", "القرآن", "قران", "تلاوة", "تلاوات", "ترتيل", "مصحف", "المصحف",
        "تجويد", "ختمة", "رقية شرعية", "آية الكرسي", "اية الكرسي",
        "surah", "surat", "sura", "quran", "quraan", "koran", "tilawa", "tilawah", "tajweed",
        "juz", "recitation", "ruqyah", "ayatul kursi",
    )

    // كلمات صريحة للأناشيد
    private val N_KEYS = keys(
        "نشيد", "أناشيد", "اناشيد", "أنشودة", "انشودة", "أنشودات", "إنشاد", "انشاد", "منشد", "نشيدة",
        "ابتهال", "ابتهالات",
        "nasheed", "nasheeds", "anasheed", "nashid", "nasyid", "inshad", "munshid",
    )

    // فرق ومنشدين معروفين
    private val N_GROUPS = keys(
        "فرقة", "نور الإيمان", "العين العالمية", "طيور الجنة", "أطفال المستقبل", "سامي يوسف",
        "ماهر زين", "حمود الخضر", "أحمد بوخاطر", "أبو راتب", "طلع البدر",
        "sami yusuf", "maher zain", "humood", "mesut kurtis", "ahmed bukhatir", "abu ratib",
        "talaa al badru", "tala al badru",
    )

    // قرّاء معروفين
    private val RECITERS = keys(
        "مشاري", "العفاسي", "عبد الباسط", "عبدالباسط", "المنشاوي", "الحصري", "السديس", "الشريم",
        "المعيقلي", "الغامدي", "الدوسري", "القطامي", "العجمي", "البلوشي", "الحذيفي", "الطبلاوي",
        "الشاطري", "بندر بليلة", "فارس عباد", "ادريس ابكر", "خالد الجليل", "علي جابر", "عبدالله بصفر",
        "رعد الكردي", "القزابري", "منصور السالمي", "وديع اليمني", "محمد أيوب", "مصطفى إسماعيل",
        "mishary", "alafasy", "afasy", "minshawi", "husary", "hussary", "sudais", "shuraim", "ghamdi",
        "dosari", "dossary", "muaiqly", "abdul basit", "abdulbasit", "abdelbasset", "qatami", "ajmi",
        "balushi", "shatri", "hudhaify", "tablawi",
    )

    private val SURAHS: Set<String> = keys(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة",
        "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت",
        "الروم", "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "الزمر", "غافر", "فصلت",
        "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "الذاريات",
        "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف",
        "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر",
        "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة",
        "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر",
        "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس",
    ).toSet()

    // أسماء سور ممكن تكون كمان اسم أغنية/شخص، فنقطها أقل
    private val AMBIGUOUS: Set<String> = keys(
        "يوسف", "مريم", "محمد", "إبراهيم", "نوح", "هود", "لقمان", "النور", "الفجر", "الشمس", "الرحمن",
        "الفتح", "الجن", "الملك", "الحديد", "الصف", "الطلاق", "طه", "الشرح", "التين", "القدر", "العصر",
    ).toSet()

    fun classify(
        title: String,
        file: String,
        artist: String,
        album: String,
        genre: String,
        path: String,
    ): Kind {
        val t = norm("$title $file")
        val titleQ = hasAny(t, Q_KEYS)
        val titleN = hasAny(t, N_KEYS)
        if (titleQ && !titleN) return Kind.QURAN
        if (titleN && !titleQ) return Kind.NASHEED

        val all = norm("$title $file $artist $album $genre $path")
        var q = 0
        var n = 0
        if (hasAny(all, Q_KEYS)) q += 5
        if (hasAny(all, N_KEYS)) n += 5
        if (hasAny(all, N_GROUPS)) n += 4
        if (hasAny(all, RECITERS)) q += 3

        // اسم الأغنية نفسه هو اسم سورة (من غير كلمات تانية)
        val core = norm(title).trim().split(' ')
            .filter { it.isNotEmpty() && it != "سوره" && it != "surah" && !it.all { ch -> ch.isDigit() } }
            .joinToString(" ")
        if (core in SURAHS && core !in AMBIGUOUS) q += 3
        else if (core in AMBIGUOUS) q += 2

        return when {
            q >= 3 && q > n -> Kind.QURAN
            n >= 4 -> Kind.NASHEED
            else -> Kind.OTHER
        }
    }
}
